﻿// Lab 4
// CIS 199-XX
// Due: 10/3/2018
// By: Andrew L. Wright (Students use Grading ID)

// This program makes an admission decision based on a student's
// high school GPA and admission test score. A student is accepted
// if the student meets either of the following requirements:
// -  A grade point average of 3.0 or higher and an admission test score of at least 60
// -  A grade point average of less than 3.0 and an admission test score of at least 80
// If the student does not meet either of the qualification criteria, then they
// are rejected.
// Running counts of number of applicants accepted/rejected are maintained.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab4
{
    public partial class AdmissionForm : Form
    {
        private uint numAccepted = 0; // Total applicants accepted
        private uint numRejected = 0; // Total applicants rejected

        public AdmissionForm()
        {
            InitializeComponent();
        }

        // Make admission decision and count # admitted/rejected
        private void admitBtn_Click(object sender, EventArgs e)
        {
            const float GPA_THRESH = 3.0f; // GPA where decision rules change
            const byte LOW_SCORE = 60;     // Admission score needed with high GPA
            const byte HIGH_SCORE = 80;    // Admission score needed with lower GPA

            float gpa;      // Entered GPA, valid >= 0
            byte testScore; // Entered test score, valid >= 0
            bool accepted;  // Was applicant accepted or not?

            // Parse input from user - TryParse is required
            if (float.TryParse(gpaTxt.Text, out gpa) && (gpa >= 0))
            {
                if (byte.TryParse(scoreTxt.Text, out testScore)) // Don't need && testScore >= 0 since unsigned
                {
                    // Make admission decision
                    if ((gpa >= GPA_THRESH) && (testScore >= LOW_SCORE))
                        accepted = true;
                    else if ((gpa < GPA_THRESH) && (testScore >= HIGH_SCORE))
                        accepted = true;
                    else
                        accepted = false;

                    // You can comment out a whole block at a time
                    // or uncomment out a whole block at a time
                    // using the Text Editor toolbar or by
                    // typing CTRL-E, C - to comment selected block
                    // typing CTRL-E, U - to uncomment selected block

                    // OR

                    //if ((gpa >= GPA_THRESH) && (testScore >= LOW_SCORE) ||
                    //    (gpa < GPA_THRESH) && (testScore >= HIGH_SCORE))
                    //    accepted = true;
                    //else
                    //    accepted = false;

                    // OR
                    //if (testScore >= HIGH_SCORE) // Automatic admission?
                    //    accepted = true;
                    //else if ((gpa >= GPA_THRESH) && (testScore >= LOW_SCORE))
                    //    accepted = true;
                    //else
                    //    accepted = false;

                    // OR

                    //if (gpa >= GPA_THRESH)
                    //    if (testScore >= LOW_SCORE)
                    //        accepted = true;
                    //    else
                    //        accepted = false;
                    //else
                    //    if (testScore >= HIGH_SCORE)
                    //    accepted = true;
                    //else
                    //    accepted = false;

                    if (accepted)
                    {
                        decisionLbl.Text = "Accept";
                        numAccepted += 1; // Increment counter
                        numAcceptedLbl.Text = $"{numAccepted}";
                    }
                    else // Rejected
                    {
                        decisionLbl.Text = "Reject";
                        numRejected += 1; // Increment counter
                        numRejectedLbl.Text = $"{numRejected}";
                    }
                }
                else
                    MessageBox.Show("Enter a non-negative test score!");
            }
            else
                MessageBox.Show("Enter a valid GPA!");
        }
    }
}
