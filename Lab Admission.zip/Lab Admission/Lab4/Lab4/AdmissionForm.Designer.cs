﻿namespace Lab4
{
    partial class AdmissionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.admitBtn = new System.Windows.Forms.Button();
            this.scoreTxt = new System.Windows.Forms.TextBox();
            this.scoreLbl = new System.Windows.Forms.Label();
            this.gpaTxt = new System.Windows.Forms.TextBox();
            this.gpaLbl = new System.Windows.Forms.Label();
            this.admissionLbl = new System.Windows.Forms.Label();
            this.decisionLbl = new System.Windows.Forms.Label();
            this.numAcceptedLbl = new System.Windows.Forms.Label();
            this.numRejectedLbl = new System.Windows.Forms.Label();
            this.acceptedLbl = new System.Windows.Forms.Label();
            this.rejectedLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // admitBtn
            // 
            this.admitBtn.Location = new System.Drawing.Point(158, 220);
            this.admitBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.admitBtn.Name = "admitBtn";
            this.admitBtn.Size = new System.Drawing.Size(112, 35);
            this.admitBtn.TabIndex = 9;
            this.admitBtn.Text = "Admit?";
            this.admitBtn.UseVisualStyleBackColor = true;
            this.admitBtn.Click += new System.EventHandler(this.admitBtn_Click);
            // 
            // scoreTxt
            // 
            this.scoreTxt.Location = new System.Drawing.Point(291, 122);
            this.scoreTxt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.scoreTxt.Name = "scoreTxt";
            this.scoreTxt.Size = new System.Drawing.Size(67, 26);
            this.scoreTxt.TabIndex = 8;
            // 
            // scoreLbl
            // 
            this.scoreLbl.AutoSize = true;
            this.scoreLbl.Location = new System.Drawing.Point(68, 128);
            this.scoreLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.scoreLbl.Name = "scoreLbl";
            this.scoreLbl.Size = new System.Drawing.Size(201, 20);
            this.scoreLbl.TabIndex = 7;
            this.scoreLbl.Text = "Enter admission test score:";
            // 
            // gpaTxt
            // 
            this.gpaTxt.Location = new System.Drawing.Point(291, 58);
            this.gpaTxt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpaTxt.Name = "gpaTxt";
            this.gpaTxt.Size = new System.Drawing.Size(67, 26);
            this.gpaTxt.TabIndex = 6;
            // 
            // gpaLbl
            // 
            this.gpaLbl.AutoSize = true;
            this.gpaLbl.Location = new System.Drawing.Point(68, 65);
            this.gpaLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.gpaLbl.Name = "gpaLbl";
            this.gpaLbl.Size = new System.Drawing.Size(197, 20);
            this.gpaLbl.TabIndex = 5;
            this.gpaLbl.Text = "Enter grade point average:";
            // 
            // admissionLbl
            // 
            this.admissionLbl.AutoSize = true;
            this.admissionLbl.Location = new System.Drawing.Point(116, 177);
            this.admissionLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.admissionLbl.Name = "admissionLbl";
            this.admissionLbl.Size = new System.Drawing.Size(151, 20);
            this.admissionLbl.TabIndex = 10;
            this.admissionLbl.Text = "Admission Decision:";
            // 
            // decisionLbl
            // 
            this.decisionLbl.AutoSize = true;
            this.decisionLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decisionLbl.Location = new System.Drawing.Point(291, 177);
            this.decisionLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.decisionLbl.Name = "decisionLbl";
            this.decisionLbl.Size = new System.Drawing.Size(0, 13);
            this.decisionLbl.TabIndex = 11;
            // 
            // numAcceptedLbl
            // 
            this.numAcceptedLbl.AutoSize = true;
            this.numAcceptedLbl.Location = new System.Drawing.Point(111, 262);
            this.numAcceptedLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numAcceptedLbl.Name = "numAcceptedLbl";
            this.numAcceptedLbl.Size = new System.Drawing.Size(18, 20);
            this.numAcceptedLbl.TabIndex = 12;
            this.numAcceptedLbl.Text = "0";
            // 
            // numRejectedLbl
            // 
            this.numRejectedLbl.AutoSize = true;
            this.numRejectedLbl.Location = new System.Drawing.Point(111, 292);
            this.numRejectedLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numRejectedLbl.Name = "numRejectedLbl";
            this.numRejectedLbl.Size = new System.Drawing.Size(18, 20);
            this.numRejectedLbl.TabIndex = 13;
            this.numRejectedLbl.Text = "0";
            // 
            // acceptedLbl
            // 
            this.acceptedLbl.Location = new System.Drawing.Point(18, 262);
            this.acceptedLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.acceptedLbl.Name = "acceptedLbl";
            this.acceptedLbl.Size = new System.Drawing.Size(84, 20);
            this.acceptedLbl.TabIndex = 14;
            this.acceptedLbl.Text = "Accepted:";
            this.acceptedLbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // rejectedLbl
            // 
            this.rejectedLbl.Location = new System.Drawing.Point(18, 292);
            this.rejectedLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.rejectedLbl.Name = "rejectedLbl";
            this.rejectedLbl.Size = new System.Drawing.Size(84, 20);
            this.rejectedLbl.TabIndex = 15;
            this.rejectedLbl.Text = "Rejected:";
            this.rejectedLbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // AdmissionForm
            // 
            this.AcceptButton = this.admitBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 326);
            this.Controls.Add(this.rejectedLbl);
            this.Controls.Add(this.acceptedLbl);
            this.Controls.Add(this.numRejectedLbl);
            this.Controls.Add(this.numAcceptedLbl);
            this.Controls.Add(this.decisionLbl);
            this.Controls.Add(this.admissionLbl);
            this.Controls.Add(this.admitBtn);
            this.Controls.Add(this.scoreTxt);
            this.Controls.Add(this.scoreLbl);
            this.Controls.Add(this.gpaTxt);
            this.Controls.Add(this.gpaLbl);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "AdmissionForm";
            this.Text = "Lab 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button admitBtn;
        private System.Windows.Forms.TextBox scoreTxt;
        private System.Windows.Forms.Label scoreLbl;
        private System.Windows.Forms.TextBox gpaTxt;
        private System.Windows.Forms.Label gpaLbl;
        private System.Windows.Forms.Label admissionLbl;
        private System.Windows.Forms.Label decisionLbl;
        private System.Windows.Forms.Label numAcceptedLbl;
        private System.Windows.Forms.Label numRejectedLbl;
        private System.Windows.Forms.Label acceptedLbl;
        private System.Windows.Forms.Label rejectedLbl;
    }
}

