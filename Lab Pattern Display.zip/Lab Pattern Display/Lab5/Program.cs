﻿/* Grading ID: B9741
 * Lab#5
 * Due Date: 10/21/18
 * CIS 199 - 02
 * Function to display 4 patternes with spaces and star to demosntrate understanding of nested for's */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lab5
{
	class Program
	{
		static void Main(string[] args)
		{
			const int NUM_ROWS_MAX = 10; // Max rows and characters per row
			const int NUM_ROWS_MIN = 1; // Min number rows and used as starting point

			Console.WriteLine("");
			Console.WriteLine("Pattern A: "); //displays name of pattern
			Console.WriteLine("");

			//Logic A
			for (int row = NUM_ROWS_MIN; row <= NUM_ROWS_MAX; row++)
			{
				for (int star = 1; star <= row; star++)
					Console.Write("*");
				Console.WriteLine();
			}

			Console.WriteLine("");
			Console.WriteLine("Pattern B: "); //displays name of pattern
			Console.WriteLine("");

			//Logic B
			for (int row = NUM_ROWS_MAX; row >= NUM_ROWS_MIN; row--)
			{
				for (int star = 1; star <= row; star++)
					Console.Write("*");
				Console.WriteLine();
			}

			Console.WriteLine("");
			Console.WriteLine("Pattern C: "); //displays name of pattern
			Console.WriteLine("");

			//Logic 3
			for (int row = NUM_ROWS_MAX; row >= NUM_ROWS_MIN; row--)
			{
				for (int space = 1; space <= NUM_ROWS_MAX - row; space++)
					Console.Write(" ");
				for (int star = 1; star <= row; star++)
					Console.Write("*");
				Console.WriteLine();

			}

			Console.WriteLine("");
			Console.WriteLine("Pattern D: "); //displays name of pattern
			Console.WriteLine("");

			//Logic 4
			for (int row = NUM_ROWS_MIN; row <= NUM_ROWS_MAX; row++)
			{
				for (int space = 1; space <= NUM_ROWS_MAX - row; space++)
					Console.Write(" ");
				for (int star = 1; star <= row; star++)
					Console.Write("*");
				Console.WriteLine();
			}
		}
	}
}
