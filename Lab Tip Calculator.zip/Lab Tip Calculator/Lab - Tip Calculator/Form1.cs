﻿//B6196
//Lab 2
//199-02
//Due: 9/10/2018
//This program calculates three different tips for a meal.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateBtn_Click(object sender, EventArgs e) //Event Handler
        {
            const double tipRate1 = .15;
            const double tipRate2 = .18;
            const double tipRate3 = .20;
                        
                   double tipLow, // Variable for a low tip
                          tipMedium, // Variable for a medium tip
                          tipHigh, // Variable for a high tip
                          inputPrice; // Variable for the price of the meal

            inputPrice = double.Parse(inputPriceTxt.Text);

            tipLow = inputPrice * tipRate1;
            tipMedium = inputPrice * tipRate2;
            tipHigh = inputPrice * tipRate3;

            tipLowLbl.Text = $"{tipLow:C}";
            tipMediumLbl.Text = $"{tipMedium:C}";
            tipHighLbl.Text = $"{tipHigh:C}";


        }
    }
}
