﻿namespace Lab2
{
    partial class Lab2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.priceLabel = new System.Windows.Forms.Label();
            this.inputpriceTxt = new System.Windows.Forms.TextBox();
            this.lowtipLabel = new System.Windows.Forms.Label();
            this.mediumtipLabel = new System.Windows.Forms.Label();
            this.hightipLabel = new System.Windows.Forms.Label();
            this.lowtipanswerLabel = new System.Windows.Forms.Label();
            this.mediumtipanswerLabel = new System.Windows.Forms.Label();
            this.hightipanswerLabel = new System.Windows.Forms.Label();
            this.tipcalcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Location = new System.Drawing.Point(15, 25);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(131, 17);
            this.priceLabel.TabIndex = 0;
            this.priceLabel.Text = "Enter price of meal:";
            // 
            // inputpriceTxt
            // 
            this.inputpriceTxt.Location = new System.Drawing.Point(152, 22);
            this.inputpriceTxt.Name = "inputpriceTxt";
            this.inputpriceTxt.Size = new System.Drawing.Size(179, 22);
            this.inputpriceTxt.TabIndex = 1;
            // 
            // lowtipLabel
            // 
            this.lowtipLabel.AutoSize = true;
            this.lowtipLabel.Location = new System.Drawing.Point(106, 65);
            this.lowtipLabel.Name = "lowtipLabel";
            this.lowtipLabel.Size = new System.Drawing.Size(40, 17);
            this.lowtipLabel.TabIndex = 2;
            this.lowtipLabel.Text = "15 %";
            // 
            // mediumtipLabel
            // 
            this.mediumtipLabel.AutoSize = true;
            this.mediumtipLabel.Location = new System.Drawing.Point(106, 105);
            this.mediumtipLabel.Name = "mediumtipLabel";
            this.mediumtipLabel.Size = new System.Drawing.Size(40, 17);
            this.mediumtipLabel.TabIndex = 3;
            this.mediumtipLabel.Text = "18 %";
            // 
            // hightipLabel
            // 
            this.hightipLabel.AutoSize = true;
            this.hightipLabel.Location = new System.Drawing.Point(106, 145);
            this.hightipLabel.Name = "hightipLabel";
            this.hightipLabel.Size = new System.Drawing.Size(40, 17);
            this.hightipLabel.TabIndex = 4;
            this.hightipLabel.Text = "20 %";
            // 
            // lowtipanswerLabel
            // 
            this.lowtipanswerLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowtipanswerLabel.Location = new System.Drawing.Point(152, 64);
            this.lowtipanswerLabel.Name = "lowtipanswerLabel";
            this.lowtipanswerLabel.Size = new System.Drawing.Size(179, 23);
            this.lowtipanswerLabel.TabIndex = 5;
            // 
            // mediumtipanswerLabel
            // 
            this.mediumtipanswerLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mediumtipanswerLabel.Location = new System.Drawing.Point(152, 104);
            this.mediumtipanswerLabel.Name = "mediumtipanswerLabel";
            this.mediumtipanswerLabel.Size = new System.Drawing.Size(179, 23);
            this.mediumtipanswerLabel.TabIndex = 6;
            // 
            // hightipanswerLabel
            // 
            this.hightipanswerLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hightipanswerLabel.Location = new System.Drawing.Point(152, 144);
            this.hightipanswerLabel.Name = "hightipanswerLabel";
            this.hightipanswerLabel.Size = new System.Drawing.Size(179, 23);
            this.hightipanswerLabel.TabIndex = 7;
            // 
            // tipcalcBtn
            // 
            this.tipcalcBtn.Location = new System.Drawing.Point(152, 187);
            this.tipcalcBtn.Name = "tipcalcBtn";
            this.tipcalcBtn.Size = new System.Drawing.Size(179, 32);
            this.tipcalcBtn.TabIndex = 8;
            this.tipcalcBtn.Text = "Calculate Tip";
            this.tipcalcBtn.UseVisualStyleBackColor = true;
            this.tipcalcBtn.Click += new System.EventHandler(this.tipcalcBtn_Click);
            // 
            // Lab2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 242);
            this.Controls.Add(this.tipcalcBtn);
            this.Controls.Add(this.hightipanswerLabel);
            this.Controls.Add(this.mediumtipanswerLabel);
            this.Controls.Add(this.lowtipanswerLabel);
            this.Controls.Add(this.hightipLabel);
            this.Controls.Add(this.mediumtipLabel);
            this.Controls.Add(this.lowtipLabel);
            this.Controls.Add(this.inputpriceTxt);
            this.Controls.Add(this.priceLabel);
            this.Name = "Lab2";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.TextBox inputpriceTxt;
        private System.Windows.Forms.Label lowtipLabel;
        private System.Windows.Forms.Label mediumtipLabel;
        private System.Windows.Forms.Label hightipLabel;
        private System.Windows.Forms.Label lowtipanswerLabel;
        private System.Windows.Forms.Label mediumtipanswerLabel;
        private System.Windows.Forms.Label hightipanswerLabel;
        private System.Windows.Forms.Button tipcalcBtn;
    }
}

