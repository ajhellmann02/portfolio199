﻿//Grading ID: B3647
//Lab 2
//Due Date: Sunday, September 16, 2018
//CIS 199-02
//This program allows the user to input the price of a meal into the text box, then with the click of the button, it will calculate
//the 3 tip amounts for that meal.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Lab2 : Form
    {
        public Lab2()
        {
            InitializeComponent();
        }

        private void tipcalcBtn_Click(object sender, EventArgs e)
        {
            const double LOW_TIP = .15; //Value for the current low tip.
            const double MEDIUM_TIP = .18; //Value for the current medium tip.
            const double HIGH_TIP = .20; //Value for the current high tip.

            double mealtotal, //Takes the entered meal price for computation
                lowtip, //Used to calculate the low tip
                mediumtip, //Used to calculate the medium tip
                hightip; //Used to calculate the high tip

            //The following line reads the entered meal price.
            mealtotal = double.Parse(inputpriceTxt.Text);

            //The following 3 lines calculate the suggested tip amount for each set of tip percentages.
            lowtip = mealtotal * LOW_TIP;
            mediumtip = mealtotal * MEDIUM_TIP;
            hightip = mealtotal * HIGH_TIP;

            //The following 3 lines of code will display the tip amounts in their associated boxes.
            lowtipanswerLabel.Text = $"{lowtip:C}";
            mediumtipanswerLabel.Text = $"{mediumtip:C}";
            hightipanswerLabel.Text = $"{hightip:C}";
        }
    }
}
